# Điều khiển LED aRGB trên ESP32-S3 bằng Home Assistant (ESPHome)

## 1. Mục tiêu
Kết nối Home Assistant với ESP32-S3 để điều khiển LED aRGB (WS2812) gắn trên chính board ESP32-S3 (màu, độ sáng, hiệu ứng).

## 2. Môi trường
| Thành phần | Chi tiết |
|---|---|
| Máy chủ | Debian 13 chạy trong VirtualBox (Bridged Adapter), tên máy `HomeVinh` |
| Home Assistant | Cài kiểu Supervised, truy cập qua cổng 80 |
| ESPHome | ESPHome Device Builder (ứng dụng trong Home Assistant) |
| Board | ESP32-S3 DevKitC-1 |
| LED | WS2812 onboard, chân GPIO48 |
| Truy cập từ xa | PuTTY (SSH) |

## 3. Các bước thực hiện
1. **Kiểm tra Home Assistant chạy**: dùng PuTTY đăng nhập vào máy chủ, chạy `sudo ha core info` và `curl -I http://localhost`. Cổng web là 80 (không phải 8123).

   ![Đăng nhập SSH bằng PuTTY vào máy ảo Debian HomeVinh](ssh_debian_homevinh.png)
   *Hình 1: Máy ảo Debian `HomeVinh` trong VirtualBox và phiên SSH bằng PuTTY.*
2. **Cài ESPHome**: Cài đặt → Ứng dụng → Cửa hàng ứng dụng → ESPHome Device Builder → Cài đặt → Bắt đầu → Hiển thị trên thanh bên.
3. **Tạo thiết bị**: Create device → Create new project → chọn board ESP32-S3 DevKitC-1 → đặt tên `hostvinh`.
4. **Viết cấu hình**: thêm khối `light:` dùng `esp32_rmt_led_strip` (xem file `hostvinh.yaml`).
5. **Nạp lần đầu qua USB**: Install → Plug into this computer → Open USB flasher (web.esphome.io) → chọn cổng COM → nạp.
6. **Nối WiFi**: ESP32 vào WiFi 2.4GHz. Nếu không vào được, nó phát hotspot dự phòng `hostvinh Fallback Hotspot`; kết nối và vào `http://192.168.4.1` để nhập WiFi.
7. **Thêm vào Home Assistant**: Cài đặt → Thiết bị & dịch vụ → thiết bị ESPHome được phát hiện → Gửi đi (nhập encryption key nếu được hỏi) → chọn khu vực.
8. **Điều khiển**: bật/tắt, chọn màu, độ sáng và các hiệu ứng `random`, `pulse`, `addressable_rainbow` trên thực thể RGB LED.

## 4. Cấu hình chính
Xem `hostvinh.yaml`. Một số điểm quan trọng:
- `restore_mode: RESTORE_DEFAULT_ON`: đèn nhớ trạng thái sau khi mất điện (mặc định đèn tắt khi khởi động).
- `power_save_mode: none`: WiFi ổn định hơn.
- `logger: hardware_uart: USB_SERIAL_JTAG`: xem log qua cổng USB native.
- Thông tin nhạy cảm (WiFi, API key) lưu trong `secrets.yaml`, không đưa lên GitHub.

## 5. Kết quả
- LED trên board sáng, điều khiển được màu, độ sáng và hiệu ứng từ Home Assistant.
- Cập nhật cấu hình về sau qua mạng bằng Install → Wirelessly, không cần cắm USB.

![ESP32-S3 sáng đèn đỏ khi chọn màu trên Home Assistant](esp32_dieu_khien_led.jpg)
*Hình 2: Chọn màu đỏ 100% trên giao diện Home Assistant, LED trên board ESP32-S3 sáng đỏ tương ứng.*

## 6. Lỗi gặp phải và cách xử lý
| Hiện tượng | Nguyên nhân | Cách xử lý |
|---|---|---|
| Không vào được web Home Assistant | Cổng thực tế là 80, không phải 8123 | Truy cập `http://IP-máy-chủ` |
| LED không sáng sau khi nạp | `restore_mode` mặc định `ALWAYS_OFF` | Thêm `restore_mode: ALWAYS_ON` hoặc `RESTORE_DEFAULT_ON` |
| Log chỉ dừng ở `entry 0x...` | Log không in ra cổng đang xem | Đặt `hardware_uart: USB_SERIAL_JTAG` và cắm cổng USB native |
| Thiết bị Offline sau khi đổi mạng | ESP32 chỉ nhớ WiFi cũ | Vào hotspot dự phòng `192.168.4.1` nhập WiFi mới, hoặc nạp lại với WiFi mới |
| Thực thể báo "Không có sẵn" | Home Assistant giữ địa chỉ cũ | Cấu hình lại ESPHome với IP/host mới |
| Lỗi "Could not open the serial port" | Cổng COM bị tab/chương trình khác chiếm | Đóng tab web.esphome.io và cửa sổ log, rút cắm lại USB |
| Hộp thoại "Name conflict" | Hai board cùng tên `hostvinh` khác MAC | Dùng một board, hoặc đổi `name:` cho board thứ hai |
| ESP32 không bắt được hotspot điện thoại | Băng tần 5GHz | Đặt hotspot ở 2.4GHz, tắt tự động tắt hotspot |

## 7. Kết luận
Hệ thống Home Assistant + ESPHome điều khiển được LED aRGB trên ESP32-S3 qua WiFi. Cần chú ý băng tần 2.4GHz, cùng mạng giữa ESP32 và máy chủ Home Assistant, và cách đặt `restore_mode` cho LED.
